<!DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
	<title>logged in</title>
	<h1>
	how are you</h1>
</head>
<body>

<div class="container">
  <div class="info">
    <h1>Online Registration System</h1>
    <h3>CSE Discipline, Khulna University</h3>
  </div>
</div>

</body>
</html>